var getScriptPromisify = (src) => {
  return new Promise((resolve) => {
    $.getScript(src, resolve);
  });
};

var load_libs_flag = false;
var tbl_borderColor = ['#4785a4', '#4785a4', '#4785a4', '#4785a4'], tbl_fillColor = "#084570";

(function () {
  const prepared = document.createElement("template");
  prepared.innerHTML = `
          <style type="text/css"></style>
          <script src= "https://code.jquery.com/jquery-3.7.1.min.js"></script>
          <div id="root"></div>
        `;

  class CustomExport extends HTMLElement {
    constructor() {
        // console.clear()
        super();
        this._shadowRoot = this.attachShadow({ mode: "open" });
        this._shadowRoot.appendChild(prepared.content.cloneNode(true));
        this._root = this._shadowRoot.getElementById("root");
        this._props = {};

        if (!load_libs_flag) {
            this.loadLibraries();
            load_libs_flag = true;
        }
    }

    async loadLibraries() {
        await getScriptPromisify("https://www.amcharts.com/lib/4/core.js");
        await getScriptPromisify("https://www.amcharts.com/lib/4/charts.js");
    }

    // getBase64ImageFromURL(url) {
    //     return new Promise((resolve, reject) => {
    //       var img = new Image();
    //       img.setAttribute("crossOrigin", "anonymous");
      
    //       img.onload = () => {
    //         var canvas = document.createElement("canvas");
    //         canvas.width = img.width;
    //         canvas.height = img.height;
      
    //         var ctx = canvas.getContext("2d");
    //         ctx.drawImage(img, 0, 0);
      
    //         var dataURL = canvas.toDataURL("image/png");
      
    //         resolve(dataURL);
    //       };
      
    //       img.onerror = error => {
    //         reject(error);
    //       };
      
    //       img.src = url;
    //     });
    // }

    onCustomWidgetBeforeUpdate(changedProperties) { 
        this._props = { ...this._props, ...changedProperties }
    }

    onCustomWidgetAfterUpdate(changedProperties) {

        if('myDataBinding' in changedProperties) {
            this.myDataBinding = changedProperties['myDataBinding']
        }

    }

    resultset(columns_per_page, rows_per_page) {

        this.table_resultset = []
        this.table_headers = [];

        this.col_dimension = this.myDataBinding.metadata.dimensions
        this.col_dimension_len = Object.keys(this.col_dimension).length;

        this.col_measure = this.myDataBinding.metadata.mainStructureMembers
        this.col_measure_len = Object.keys(this.col_measure).length;

        //// Table Headers Starts ===============================
        var dim_header = [];
        for(var j = 0; j < this.col_dimension_len; j++) {
            dim_header.push({ text: this.col_dimension["dimensions_"+j.toString()]["description"], bold: true, fillColor: tbl_fillColor, color:"white", borderColor: tbl_borderColor })
        }

        var mes_header = [...dim_header.slice(0, columns_per_page + dim_header.length)];

        for(var j = 0, cnt = 0; j <= this.col_measure_len; j++) {

            if(cnt >= columns_per_page) {
                this.table_headers.push([...mes_header.slice()])
                mes_header = [...dim_header.slice(0, mes_header.length)];
                cnt = 0;
            }

            if(cnt != 0 && j >= this.col_measure_len) {
                this.table_headers.push([...mes_header.slice()])
            }

            cnt++;

            if(this.col_measure["measures_"+j.toString()]) {
                mes_header.push({ text: this.col_measure["measures_"+j.toString()]["label"], alignment:'right', bold: true, fillColor: tbl_fillColor, color:"white", borderColor: tbl_borderColor })
            }
           
        }

        // console.log(this.table_headers, "---------")
        //// Table Headers Ends ==================================

        //// Table Data Starts ===================================

        var res_arr = []
        var pages = []
        var dim_indices = new Set();

        for(var i = 0, rcnt = 0; i < this.myDataBinding.data.length; i++) {

            var temp_arr = [];

            dim_indices.add(temp_arr.length);

            for(var j = 0; j < this.col_dimension_len; j++) {

                temp_arr.push({text: this.myDataBinding.data[i]["dimensions_"+j.toString()]["label"], borderColor: tbl_borderColor});

            }

            for(var j = 0, ccnt = 0; j < this.col_measure_len; j++) {

                if(ccnt == columns_per_page) {
                    dim_indices.add(temp_arr.length);
                    for(var k = 0; k < this.col_dimension_len; k++) {
                        temp_arr.push({text: this.myDataBinding.data[i]["dimensions_"+k.toString()]["label"], borderColor: tbl_borderColor});
                    }
                    ccnt = 0;
                } 
                    
                temp_arr.push({ text: this.myDataBinding.data[i]["measures_"+j.toString()]["formatted"], alignment:'right', borderColor: tbl_borderColor });

                ccnt++;
            }
            
            if(rcnt == rows_per_page) {
                res_arr.push(pages.slice())
                pages = [];
                rcnt = 0;
            }

            pages.push(temp_arr.slice());

            if(rcnt != 0 && i >= this.myDataBinding.data.length - 1) {
                res_arr.push(pages.slice())
            }

            rcnt++;

        }
        this.table_resultset = res_arr;
        dim_indices = Array.from(dim_indices)
        dim_indices.shift()
        this.dim_indices = dim_indices;

        // console.log("***", res_arr)

        //// Table Data Ends =====================================

    }

    exportToPDF(header = {}, add_ons = {}, footer = {}) {
       
        if (!this.myDataBinding || this.myDataBinding.state !== 'success') {
            return
        }

        if (!load_libs_flag) {
            this.loadLibraries();
            load_libs_flag = true;
        }

        var columns_per_page = parseInt(add_ons["no_of_columns"])
        var rows_per_page = parseInt(add_ons["no_of_rows"])

        this.resultset(columns_per_page, rows_per_page)

        //// Header Info
        var logo_url = header['logo'];
        var logo_width = JSON.parse(header['ratio'])[0];
        var logo_height = JSON.parse(header['ratio'])[1];
        var logo_margin = JSON.parse(header["margin"]);

        //// Add on Info
        var page_margin = JSON.parse(add_ons["page_margin"])
        var filters = JSON.parse(add_ons['filters']);

        //// Footer Info
        var userInfo = footer["user"];

        var table_headers = this.table_headers;
        var table_resultset = this.table_resultset;
        var dim_indices = this.dim_indices;
        var dims = this.col_dimension;
      

        console.log("Databinding Info : \n", this.col_dimension, this.col_measure, this.myDataBinding)
        console.log("Split by Columns : ", columns_per_page);
        console.log("Dimesion Indices : ", this.dim_indices);
        console.log("\nExport Table Headers : ", this.table_headers)
        console.log("Table Resultset : ", this.table_resultset)
       
        if(am4core || am4core == undefined) {
            this.loadLibraries();
        }

        var chart = am4core.create(this._root, am4charts.XYChart);

            
        chart.exporting.pdfmake.then(function(pdfmake) {

            var doc = 
            {
                pageSize: "A4",
                pageOrientation: "portrait",
                // pageMargins: [25, 20, 25, 25],
                pageMargins: page_margin,
                content: [],
                images: {
                    logo: {
                        url:logo_url,
                    //   url: 'https://digital-sweep.eu10.hcs.cloud.sap/sap/fpa/services/rest/epm/security/photo/284802604DBC67181900600A893CF11F?tenant=B&',
                    }
                },
                footer: function(currentPage, pageCount) { 
                    // var 
                    return [{
                        columns: [
                            {text: 'Exported by : ' + userInfo, alignment:'left', fontSize:10, margin:[20,0,0,0], color:'#0192d1'},
                            {text:currentPage.toString() + ' of ' + pageCount, alignment:'center', fontSize:10, margin:[0,0,0,0], color:'#0192d1'},
                            {text: (new Date()).toLocaleString(), alignment:'right', fontSize:10,margin:[0,0,20,0], color:'#0192d1'},
                        ]
                    }]
                },
            };

            //// Creating Pages based on Columns from SAC
            var pageBreak = "after";

            // doc.content.push( {
            //     image:'logo',
            //     width:logo_width,
            //     height:logo_height,
            //     margin: logo_margin,
            // });

            // doc.content.push(
            //     { 
            //         text: 'Filters Applied ', 
            //         bold: true, 
            //         color:"#004169", 
            //         fontSize:15 ,
            //         margin: [0,0,0,10],
            //     }
            // );

            let filter_obj_cnt = 0, filter_obj_len = Object.keys(filters).length;

            for(var i = 0, pg_cnt = 1; i < table_headers.length; i++) {

                for(var k = 0; k < table_resultset.length; k++, pg_cnt++) {

                    var temp_arr = [JSON.parse(JSON.stringify(table_headers[i]))];

                    doc.content.push( {
                        image:'logo',
                        width:logo_width,
                        height:logo_height,
                        margin: logo_margin,
                    });

                    if(pg_cnt == 1) {

                        doc.content.push(
                           { 
                               text: 'Report Filtered On : ', 
                               bold: true, 
                               color:"#004169", 
                               fontSize:15 ,
                               margin: [0,0,0,8],
                           }
                       );

                       var filter_text = "";
                       
                       for(var f in filters) {
                
                            if(filter_obj_cnt == filter_obj_len - 1) {
                                filter_text += f + " : " + filters[f] + ".";
                                // doc.content.push(
                                //     { 
                                //         text: f + " : " + filters[f] + ".", 
                                //         color:"#004169", 
                                //         fontSize:12,
                                //         margin: [0,0,0,10],
                                //     }
                                // );
                            } else {
                                filter_text += f + " : " + filters[f] + ",  ";
                                // doc.content.push(
                                //     { 
                                //         text: f + " : " + filters[f] + ",", 
                                //         color:"#004169", 
                                //         fontSize:12,
                                //     }
                                // );
                            }
            
                            filter_obj_cnt++;
            
                            // console.log(k, filters[k])
                        }

                         doc.content.push(
                            { 
                                text: filter_text, 
                                color:"#004169", 
                                fontSize:12,
                                margin: [0,0,0,10],
                            }
                        );
                   }

                    for(var j = 0; j < table_resultset[k].length; j++) {
                        if(i == 0) {
                            temp_arr.push(table_resultset[k][j].slice(0, dim_indices[i]))
                        } else {
                            if(dim_indices[i - 1]) {
                                temp_arr.push(table_resultset[k][j].slice(dim_indices[i - 1], dim_indices[i - 1] + Object.keys(dims).length + columns_per_page))
                            } 
                        }
                    }

                    console.log("Page "+ pg_cnt.toString() +" : ", temp_arr)

                    // console.log(temp_arr);

                    if(i == table_headers.length - 1 && k == table_resultset.length - 1) {
                        pageBreak = ""
                    }

                    var widths_arr = Array(temp_arr[0].length).fill('auto');
                    // widths_arr[0] = 'auto';
                    // widths_arr[1] = 30;

                    doc.content.push({
                        table: {
                            headerRows: 1,
                            widths:widths_arr,
                            dontBreakRows: true,
                            // widths: ["*", "*", "*", "*"],
                            body: temp_arr.slice(),
                        },
                        pageBreak: pageBreak,
                        layout: {
                            // fillColor: function (rowIndex, node, columnIndex) {
                            //     return (rowIndex % 2 === 0) ? '#e3e3e3' : null;
                            // }
                        }
                    });

                }
            }

            pdfmake.createPdf(doc).download("report.pdf");

        });

    }
  }
  customElements.define("cw-export-to-pdf", CustomExport);
})();
