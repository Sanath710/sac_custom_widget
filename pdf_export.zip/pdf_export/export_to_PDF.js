var getScriptPromisify = (src) => {
  return new Promise((resolve) => {
    $.getScript(src, resolve);
  });
};

var load_libs_flag = false;

(function () {
  const prepared = document.createElement("template");
  prepared.innerHTML = `
          <style type="text/css"></style>
          <script src= "https://code.jquery.com/jquery-3.7.1.min.js"></script>
          <div id="root"></div>
        `;

  class CustomExport extends HTMLElement {
    constructor() {
        // console.clear()
        super();
        this._shadowRoot = this.attachShadow({ mode: "open" });
        this._shadowRoot.appendChild(prepared.content.cloneNode(true));
        this._root = this._shadowRoot.getElementById("root");
        this._props = {};

        if (!load_libs_flag) {
            this.loadLibraries();
            load_libs_flag = true;
        }
    }

    async loadLibraries() {
        await getScriptPromisify("https://www.amcharts.com/lib/4/core.js");
        await getScriptPromisify("https://www.amcharts.com/lib/4/charts.js");
    }

    // getBase64ImageFromURL(url) {
    //     return new Promise((resolve, reject) => {
    //       var img = new Image();
    //       img.setAttribute("crossOrigin", "anonymous");
      
    //       img.onload = () => {
    //         var canvas = document.createElement("canvas");
    //         canvas.width = img.width;
    //         canvas.height = img.height;
      
    //         var ctx = canvas.getContext("2d");
    //         ctx.drawImage(img, 0, 0);
      
    //         var dataURL = canvas.toDataURL("image/png");
      
    //         resolve(dataURL);
    //       };
      
    //       img.onerror = error => {
    //         reject(error);
    //       };
      
    //       img.src = url;
    //     });
    // }

    onCustomWidgetBeforeUpdate(changedProperties) { 
        this._props = { ...this._props, ...changedProperties }
    }

    onCustomWidgetAfterUpdate(changedProperties) {

        if('myDataBinding' in changedProperties) {
            this.myDataBinding = changedProperties['myDataBinding']
        }

    }

    resultset(columns_per_page) {

        this.table_resultset = []
        this.table_headers = [];

        this.col_dimension = this.myDataBinding.metadata.dimensions
        this.col_dimension_len = Object.keys(this.col_dimension).length;

        this.col_measure = this.myDataBinding.metadata.mainStructureMembers
        this.col_measure_len = Object.keys(this.col_measure).length;

        // Table Headers ===============================
        var dim_header = [];
        for(var j = 0; j < this.col_dimension_len; j++) {
            dim_header.push({ text: this.col_dimension["dimensions_"+j.toString()]["description"], bold: true })
        }

        var mes_header = [...dim_header.slice(0, columns_per_page + dim_header.length)];

        for(var j = 0, cnt = 0; j <= this.col_measure_len; j++) {
            if(cnt >= columns_per_page) {
                this.table_headers.push([...mes_header.slice()])
                mes_header = [...dim_header.slice(0, mes_header.length)];
                cnt = 0;
            }

            if(cnt != 0 && j >= this.col_measure_len) {
                this.table_headers.push([...mes_header.slice()])
            }

            cnt++;

            if(this.col_measure["measures_"+j.toString()]) {
                mes_header.push({ text: this.col_measure["measures_"+j.toString()]["label"], bold: true })
                // dim_header.push({ text: "", bold: true })
            }
           
        }

        // console.log(this.table_headers, "---------")
        // =============================================

        // Table Data ==================================

        var res_arr = []
        var dim_indices = new Set();

        for(var i = 0; i < this.myDataBinding.data.length; i++) {

            var temp_arr = [];

            dim_indices.add(temp_arr.length);

            for(var j = 0; j < this.col_dimension_len; j++) {
                temp_arr.push(this.myDataBinding.data[i]["dimensions_"+j.toString()]["label"]);
            }

            for(var j = 0, cnt = 0; j < this.col_measure_len; j++) {

                if(cnt == columns_per_page) {

                    dim_indices.add(temp_arr.length);

                    for(var k = 0; k < this.col_dimension_len; k++) {
                        temp_arr.push(this.myDataBinding.data[i]["dimensions_"+k.toString()]["label"]);
                    }

                    cnt = 0;

                } 
                    
                temp_arr.push(this.myDataBinding.data[i]["measures_"+j.toString()]["formatted"]);

                cnt++;
            }
            
            res_arr.push(temp_arr);

        }
        this.table_resultset = res_arr;
        dim_indices = Array.from(dim_indices)
        dim_indices.shift()
        this.dim_indices = dim_indices;

        // ===============================================

        // console.log("Table Resultset : \n", this.table_resultset)
    }

    exportToPDF(columns_per_page, rows_per_page) {

        if (!this.myDataBinding || this.myDataBinding.state !== 'success') {
            return
        }

        if (!load_libs_flag) {
            this.loadLibraries();
            load_libs_flag = true;
        }

        columns_per_page = parseInt(columns_per_page)

        this.resultset(columns_per_page)

        var table_headers = this.table_headers;
        var table_resultset = this.table_resultset;
        var dim_indices = this.dim_indices;
        var dims = this.col_dimension;
        rows_per_page = parseInt(rows_per_page)
      

        console.log("Databinding Info : \n", this.col_dimension, this.col_measure, this.myDataBinding)
        console.log("Split by Columns : ", columns_per_page);
        console.log("Dimesion Indices : ", this.dim_indices);
        console.log("\nExport Table Headers : ", this.table_headers)
        console.log("Table Resultset : ", this.table_resultset)
       
        if(!am4charts) {
            this.loadLibraries();
        }

        var chart = am4core.create(this._root, am4charts.XYChart);

            
        chart.exporting.pdfmake.then(function(pdfmake) {

            var doc = 
            {
                pageSize: "A4",
                pageOrientation: "portrait",
                pageMargins: [25, 25, 25, 25],
                content: [
                    // {
                    //     image:'logo',
                    //     fit: [119, 54]
                    // }
                ],
                // pageBreakBefore: function(currentNode, followingNodesOnPage, nodesOnNextPage, previousNodesOnPage) {
                //     console.log(currentNode)
                //     // if ((currentNode.pageNumbers.length != 1 || currentNode.pageNumbers[0] != currentNode.pages)) {
                //     //     console.log("RETURN TRUE")
                //     //     return true;
                //     // }
                //     // console.log("RETURN FALSE")
                //   },
                images: {
                    logo: {
                      url: 'https://digital-sweep.eu10.hcs.cloud.sap/sap/fpa/services/rest/epm/security/photo/284802604DBC67181900600A893CF11F?tenant=B&',
                    }
                },
            };

            //// Creating Pages based on Columns from SAC
            var pageBreak = "";

            for(var i = 0 ; i < table_headers.length; i++) {

                if(i != 0){
                    pageBreak = "before";  
                }

                doc.content.push( {
                    image:'logo',
                    fit: [119, 54],
                    margin: [0, 0, 0, 15],
                    pageBreak: pageBreak,
                    
                });

                var temp_arr = [JSON.parse(JSON.stringify(table_headers[i]))];

                for(var j = 0; j < table_resultset.length; j++) {
                    if(i == 0) {
                        temp_arr.push(table_resultset[j].slice(0, dim_indices[i]))
                    } else {
                        if(dim_indices[i]) {
                            temp_arr.push(table_resultset[j].slice(dim_indices[i], dim_indices[i] + Object.keys(dims).length + columns_per_page))
                        } else {
                            temp_arr.push(table_resultset[j].slice(dim_indices[i - 1]))
                        }
                    }

                    // if(temp_arr.length >= rows_per_page) {
                    //     doc.content.push({
                    //         table: {
                    //             headerRows: 1,
                    //             dontBreakRows: true,
                    //             // widths: ["*", "*", "*", "*"],
                    //             body: temp_arr.slice(),
                    //         },
                    //     });

                    //     // doc.content.push( {
                    //     //     image:'logo',
                    //     //     fit: [119, 54],
                    //     //     margin: [0, 0, 0, 15],
                    //     //     pageBreak: pageBreak,
                            
                    //     // });
                        
                    //     temp_arr = [JSON.parse(JSON.stringify(table_headers[i]))];
                    //     // temp_arr.push(table_resultset[j].slice(0, dim_indices[i]))
                    // }
                }

                console.log("Page "+ i.toString() +" : ", temp_arr)

                // console.log(temp_arr);

                doc.content.push({
                    table: {
                        headerRows: 1,
                        dontBreakRows: true,
                        // widths: ["*", "*", "*", "*"],
                        body: temp_arr.slice(),
                    },
                });
            }

            // doc.content.push( {
            //     image:'logo',
            //     fit: [119, 54],
            //     margin: [0, 20, 0, 15],
            //     pageBreak: 'before'
            // });
            // doc.content.push({
            //     table: {
            //         headerRows: 1,
            //         // widths: ["*", "*", "*", "*"],
            //         body: [
            //             [
            //                 { text: "Company Code", bold: true },
            //                 { text: "FY", bold: true },
            //                 { text: "", bold: true },
            //                 { text: "", bold: true },
            //             ],
            //             [
            //                 { text: "", bold: true },
            //                 { text: "", bold: true },
            //                 { text: "1", bold: true },
            //                 { text: "2", bold: true },
            //             ],
            //             ["1500", { text: "2500", color: "red" }, "2200", "1200"],
            //             ["100", "1200", "990", "708"],
            //             ["100", "2150", "900", "1260"],
            //         ],
            //     },
            // });

            // doc.content.push({
            //     table: {
            //         headerRows: 1,
            //         // widths: ["*", "*", "*", "*"],
            //         body: [
            //             [
            //                 { text: "Company Code", bold: true },
            //                 { text: "FY", bold: true },
            //                 { text: "", bold: true },
            //                 { text: "", bold: true },
            //             ],
            //             [
            //                 { text: "", bold: true },
            //                 { text: "", bold: true },
            //                 { text: "3", bold: true },
            //                 { text: "4", bold: true },
            //             ],
            //         ["1500", { text: "2500", color: "red" }, "2200", "1200"],
            //         ["100", "1200", "990", "708"],
            //         ["100", "2150", "900", "1260"],
            //         ],
            //     },
            // });

            // doc.content.push({
            //     table: {
            //         headerRows: 1,
            //         widths: ["*", "*", "*", "*"],
            //         body: [
            //             [
            //                 { text: "Company Code", bold: true },
            //                 { text: "FY", bold: true },
            //                 { text: "", bold: true },
            //                 { text: "", bold: true },
            //             ],
            //             [
            //                 { text: "", bold: true },
            //                 { text: "", bold: true },
            //                 { text: "5", bold: true },
            //                 { text: "6", bold: true },
            //             ],
            //         ["1500", { text: "2500", color: "red" }, "2200", "1200"],
            //         ["100", "1200", "990", "708"],
            //         ["100", "2150", "900", "1260"],
            //         ],
            //     },
            // });

            // chart.data = [
            //     {
            //         date: new Date(2018, 0, 1),
            //         value: 450,
            //         value2: 362,
            //         value3: 699,
            //     },
            // ];

            pdfmake.createPdf(doc).download("report.pdf");

        });

    }

    // async exportToExcel(callFrom) {

    //     var chart = am4core.create(this._exportToExcel_root, am4charts.XYChart);

    //     chart.exporting.dataFields = topHeader_ExportToExcel_5Y_QT;

    //     var data = [this._dataTableObj.columns().header().map(d => d.textContent).toArray()];

    //     for(var i = 0; i < this._dataTableObj.rows().count(); i++) {
    //         data.push(this._dataTableObj.rows(i).data()[0])
    //     }

    //     // console.log(data)

    //     var regex = '<option[^>]*selected="selected">(.*?)<\/option>';
    //     var gxColIds = [55, 108, 161];

    //     for(var i = 0; i < gxColIds.length; i++) {
    //         for(var j =0; j < this._dataTableObj.columns(gxColIds[i]).data()[0].length; j++) {
    //             var d = this._dataTableObj.columns(gxColIds[i]).data()[0][j];
    //             if(d.includes("<option")) {
    //                 // console.log(data[i], data[j])
    //                 data[j][gxColIds[i]] = d.match(regex)[1]
    //             }
    //         }
    //     }

    //     // var d = this._dataTableObj.columns(55).data()[0][2]
    //     // console.log(d.match(regex)[1])

    //     chart.data = data;

    //     chart.exporting.export("xlsx");

    // }
  }
  customElements.define("cw-export-to-pdf", CustomExport);
})();
