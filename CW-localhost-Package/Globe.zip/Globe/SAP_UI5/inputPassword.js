var getScriptPromisify = src => {
    return new Promise(resolve => {
      $.getScript(src, resolve)
    })
  }
  
  ;(function () {

    let _shadowRoot;
    let _id;
    let _password;

    let tmpl = document.createElement('template')
    tmpl.innerHTML = `
                <style>
                </style>
                <div id="ui5_content" name="ui5_content">
                    <slot name="content"></slot>
                </div>

                <script id="oView" name="oView" type="sapui5/xmlview">
                    <mvc:View
                        controllerName="myView.Template"
                        xmlns="sap.m"
                        xmlns:mvc="sap.ui.core.mvc"
                        xmlns:l="sap.ui.layout">
                        <l:VerticalLayout class="sapUiContentPadding" width="100%">
                                <Label text="Password" labelFor="passwordInput" />
                                <Input
                                    id="passwordInput"
                                    type="Password"
                                    placeholder="Enter password..." liveChange="onButtonPress"/>
                        </l:VerticalLayout>
                    </mvc:View>
                </script>
              `
  
    class customInpPass extends HTMLElement {
      constructor () {
        super()
        _shadowRoot = this.attachShadow({ mode: 'open' })
        _shadowRoot.appendChild(tmpl.content.cloneNode(true))
        _id = 1;
        _shadowRoot.querySelector("#oView").id = _id + "_oView";

        this._export_settings = {};
        this._export_settings.password = "";

        this.addEventListener("click", event => {
            console.log("click");
        })
      }

      onCustomWidgetAfterUpdate(changedProperties) {
        loadthis(this);
      }

      _firePropertiesChanged() {
        this.password = "";
        this.dispatchEvent(new CustomEvent("propertiesChanged", {
            detail:{
                properties:{
                    password: this.password
                }
            }
        }));
      }

      get password() {
        return this._export_settings.password;
      }

      set password(value) {
        value = _password;
        this._export_settings.password = value;
      }

      static get observedAttributes() {
        return [
            "password"
        ];
      }

      attributeChangedCallback(name, oldValue, newValue) {
        if(oldValue != newValue) {
            this[name] = newValue;
        }
      }

    }
    customElements.define('inp-pass', customInpPass)

    function loadthis(that) {

        var that_ = that;

        let content = document.createElement('div');
        content.slot = "content";
        that_.appendChild(content);

        sap.ui.getCore().attachInit(function() {
            
            "use strict";

            sap.ui.define([
                "jquery.sap.global",
                "sap/ui/core/mvc/Controller"
            ], function(jQuery, Controller) {

                "use strict";

                return Controller.extend("myView.Template", {
                    onButtonPress:function(oEvent) {
                        _password = oView.byId("passwordInput").getValue();
                        that._firePropertiesChanged();
                        console.log(_password);

                        this.settings = {};
                        this.settings.password = "";

                        // const node =  document.createElement("p");
                        // const textnode = document.createTextNode("Hello");
                        // node.appendChild(textnode);
                        // _shadowRoot.getElementById(_id + "_oView").appendChild(node)

                        that.dispatchEvent(new CustomEvent("onStart", {
                            detail:{
                                settings:this.settings
                            }
                        }));
                    }
                });
            });

            var oView = sap.ui.xmlview({
                viewContent:jQuery(_shadowRoot.getElementById(_id + "_oView")).html(),
            });
            oView.placeAt(content);

            if(that_._designMode) {
                oView.byId("passwordInput").setEnabled(false);
            }
        });
    }
  })()
  