var getScriptPromisify = src => {
    return new Promise(resolve => {
      $.getScript(src, resolve)
    })
  }
  
  ;(function () {
    const prepared = document.createElement('template')
    prepared.innerHTML = `
            <style type="text/css">
              @import url("https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css");
              @import url("https://cdn.datatables.net/2.0.1/css/dataTables.bootstrap5.css");
              @import url("https://cdn.datatables.net/buttons/3.0.0/css/buttons.bootstrap5.css");
              
              input[type="search"]  {
                border:1px solid #dee2e6;
              }
  
              table.table.dataTable.table-striped > tbody > tr {
                border:0.1px solid #dee2e6;
                padding:1.2%;
              }
  
              table.table.dataTable.table-striped > tbody > tr:nth-of-type(2n+1) > * {
                background-color:#f2f2f2;
              }
  
            </style>
            <script src= "https://code.jquery.com/jquery-3.7.1.js"></script> 
  
            <div id="root" style="width: 100%; height: 100%; padding:1.5%;display:grid;">
              <table id="example" class="table table-striped" style="width:100%">
                <thead>
                </thead>
                <tbody></tbody>
              </table>
            </div>
          `
  
    class CustomTable extends HTMLElement {
      constructor () {
        super()
        this._shadowRoot = this.attachShadow({ mode: 'open' })
        this._shadowRoot.appendChild(prepared.content.cloneNode(true))
        this._root = this._shadowRoot.getElementById('root')
        this._table = this._shadowRoot.getElementById('example')
        this._props = {}
        this.render()
      }
  
      onCustomWidgetBeforeUpdate (changedProperties) {
        this._props = { ...this._props, ...changedProperties }
      }
  
      onCustomWidgetAfterUpdate (changedProperties) {
        if ('myDataBinding' in changedProperties) {
          this.myDataBinding = changedProperties['myDataBinding']
          // this.render()
        }
        console.log('hello1')
        console.log(this.myDataBinding)
      }
  
      // onCustomWidgetResize (width, height) {
      //   this.render()
      // }
  
      async render () {
        // await getScriptPromisify('https://code.jquery.com/jquery-3.7.1.js');
  
        await getScriptPromisify(
          'https://cdn.datatables.net/2.0.1/js/dataTables.js'
        )
        await getScriptPromisify(
          'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js'
        )
        await getScriptPromisify(
          'https://cdn.datatables.net/2.0.1/js/dataTables.bootstrap5.js'
        )
        await getScriptPromisify(
          'https://cdn.datatables.net/buttons/3.0.0/js/dataTables.buttons.js'
        )
        await getScriptPromisify(
          'https://cdn.datatables.net/buttons/3.0.0/js/buttons.bootstrap5.js'
        )
        await getScriptPromisify(
          'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js'
        )
        await getScriptPromisify(
          'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js'
        )
        await getScriptPromisify(
          'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js'
        )
        await getScriptPromisify(
          'https://cdn.datatables.net/buttons/3.0.0/js/buttons.html5.min.js'
        )
        await getScriptPromisify(
          'https://cdn.datatables.net/buttons/3.0.0/js/buttons.print.min.js'
        )
        // await getScriptPromisify('https://cdn.datatables.net/buttons/3.0.0/js/buttons.colVis.min.js')
  
        if (!this.myDataBinding || this.myDataBinding.state !== 'success') {
          return
        }
  
        console.log('Data Binding Success')
  
        var table_cols = []
  
        var col_dimension = this.myDataBinding.metadata.dimensions
        var col_measure = this.myDataBinding.metadata.mainStructureMembers
  
        for (
          var i = 0;
          i < this.myDataBinding.metadata.feeds.dimensions.values.length;
          i++
        ) {
          var k = 'dimensions_' + i.toString()
          table_cols.push({
            title: col_dimension[k].id
          })
        }
  
        for (
          var i = 0;
          i < this.myDataBinding.metadata.feeds.measures.values.length;
          i++
        ) {
          var k = 'measures_' + i.toString()
          table_cols.push({
            title: col_measure[k].id
          })
        }
  
        console.log(table_cols)
  
        const tbl = new DataTable(this._table, {
          // initComplete: function () {
          //   this.api()
          //     .columns()
          //     .every(function () {
          //       let column = this
  
          //       // Create select element
          //       let select = document.createElement('select')
          //       select.add(new Option(''))
          //       column.header().replaceChildren(select)
  
          //       // Apply listener for user change in value
          //       select.addEventListener('change', function () {
          //         column.search(select.value, { exact: true }).draw()
          //       })
  
          //       // Add list of options
          //       column
          //         .data()
          //         .unique()
          //         .sort()
          //         .each(function (d, j) {
          //           select.add(new Option(d))
          //         })
          //     })
          // },
          layout: {
            topStart: {
              buttons: ['copy', 'excel', 'pdf', 'colvis']
            }
          },
          columns: table_cols,
          columnDefs: [
            {
              defaultContent: '-',
              targets: '_all'
              // className: 'dt-body-left'
            }
          ],
          bDestroy: true
        })
  
        // tbl.on('click', 'tbody tr', e => {
        //   let classList = e.currentTarget.classList
  
        //   if (classList.contains('selected')) {
        //     classList.remove('selected')
        //   } else {
        //     tbl
        //       .rows('.selected')
        //       .nodes()
        //       .each(row => row.classList.remove('selected'))
        //     classList.add('selected')
        //   }
        // })
  
        // console.log(this.myDataBinding)
  
        var transformed_data = []
  
        var cnt_dimensions = this.myDataBinding.metadata.feeds.dimensions.values
        var cnt_measures = this.myDataBinding.metadata.feeds.measures.values
  
        for (var i = 0; i < this.myDataBinding.data.length; i++) {
          var tbl_row_data = []
  
          // Dynamic 'N' keys
          var key = ''
  
          for (var j = 0; j < cnt_dimensions.length; j++) {
            var dim_key = cnt_dimensions[j]
            key += this.myDataBinding.data[i][dim_key].label + '_#_'
            tbl_row_data.push(this.myDataBinding.data[i][dim_key].label)
          }
  
          //  Dynamic 'N' values
          var measure_objs = {}
  
          for (var j = 0; j < cnt_measures.length; j++) {
            var measure_key = cnt_measures[j]
            measure_objs[measure_key] = this.myDataBinding.data[i][measure_key]
            tbl_row_data.push(this.myDataBinding.data[i][measure_key].formatted)
          }
  
          if (tbl_row_data.length > 0) {
            tbl.row.add(tbl_row_data).draw(false)
            tbl.columns.adjust().draw()
          }
          // console.log("Tbl");
          // console.log(tbl_row_data);
  
          var temp_obj = {}
          temp_obj[key] = measure_objs
  
          transformed_data.push(temp_obj)
        }
  
        console.log('Formatted Data')
        console.log(transformed_data)
      }
    }
    customElements.define('custom-table', CustomTable)
  })()
  