;

var windowObjectReference = {};

(function () {

    class CustomOpenTab extends HTMLElement {

        constructor () {
            super()
            this._props = {}
        }

        onCustomWidgetBeforeUpdate (changedProperties) {}

        onCustomWidgetAfterUpdate (changedProperties) {}

        openLink(url_link) {

            function openRequestedTab(url, windowName) {
                
                if(!Object.keys(windowObjectReference).includes(url_link)) {
                    windowObjectReference[url_link] = window.open(url, windowName); 
                } else {
                    if(windowObjectReference[url_link].closed) {
                        windowObjectReference[url_link] = window.open(url, windowName); 
                    }
                    windowObjectReference[url_link].focus();
                }
            }
    
            openRequestedTab(url_link);

        }
    }

    customElements.define('cw-open-tabs', CustomOpenTab)

})()
