var getScriptPromisify = src => {
    return new Promise(resolve => {
      $.getScript(src, resolve)
    })
  }
  ;(function () {
    const prepared = document.createElement('template')
    prepared.innerHTML = `
                  <style>
                  </style>
                  <div id="map_div" style="width: 100%; height: 100%;">
                  </div>
                `
  
    class GoogleChartMap extends HTMLElement {
      constructor () {
        //   console.clear()
        super()
        this._shadowRoot = this.attachShadow({ mode: 'open' })
        this._shadowRoot.appendChild(prepared.content.cloneNode(true))
        this._root = this._shadowRoot.getElementById('map_div')
        this._props = {}
  
      }
  
      onCustomWidgetBeforeUpdate (changedProperties) {
        this._props = { ...this._props, ...changedProperties }
      }
  
      onCustomWidgetAfterUpdate (changedProperties) {
        this._myDataBinding = changedProperties['myDataBinding']
        console.log("After Update")
        console.log(this._myDataBinding)
        this.render(this._root)
      }
  
      async render (root) {
          
        await getScriptPromisify('https://www.gstatic.com/charts/loader.js');

        if(this._myDataBinding.state != 'success') {
          return;
        }

        var _data = [['Lat', 'Long', 'Name']];
        for(var i = 0; i < this._myDataBinding["data"].length; i++) {
            var arr = []
            arr.push(this._myDataBinding["data"][i]["measures_0"].raw);
            arr.push(this._myDataBinding["data"][i]["measures_1"].raw);
            arr.push(this._myDataBinding["data"][i]["dimensions_0"].label);
            _data.push(arr)
        }

        console.log(_data);

        google.charts.load("current", {
            "packages":["map"],
            // Note: you will need to get a mapsApiKey for your project.
            // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
            "mapsApiKey": "AIzaSyD40b4ts50KSxvh09nHy30SNBl8Zh8B1x0"
          });

          google.charts.setOnLoadCallback(drawChart);
          function drawChart() {
            var data = google.visualization.arrayToDataTable(_data);
    
            var map = new google.visualization.Map(root);
            map.draw(data, {
              showTooltip: true,
              showInfoWindow: true
            });
          }

      }
    }
    customElements.define('cw-gc-map', GoogleChartMap)
  })()
  